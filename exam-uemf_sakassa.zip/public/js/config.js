export const url=" http://localhost:3000"


export const questionInput = document.getElementById("questionInput");
export const resetBtn = document.getElementById("resetBtn");
export const submitBtn = document.getElementById("submitBtn");
export const trueoption = document.getElementById("trueoption");
export const falseoption = document.getElementById("falseoption");