import {resetBtn, questionInput, submitBtn,trueoption,falseoption} from "./config.js"
import { addQuestion, deleteQuestion,load,deleteall} from "./question.js";

load();
submitBtn.addEventListener('click',()=>{
    const question=questionInput.value
    const option=trueoption.value || falseoption.value
        if(!question)
        return alert("please provide a content for your question")
    
        addQuestion(question,option)
})
resetBtn.addEventListener('click',()=>{
    deleteall()
})



export const addquestiontodiv=(question)=>{
    const {quest,etat,_id} = question

    // // creation des elemments
   
    const div = document.createElement('div');
    div.classList.add("question",etat);
    const span = document.createElement('span');
    span.classList.add("idQuestion");
    span.innerHTML =_id
    const q = document.createElement('div');
    q.classList.add("content");
    q.innerHTML=quest;
    const btndelete= document.createElement("button")
    const btnswitch= document.createElement("button")


    
    btndelete.innerText="delete"
    btnswitch.innerText="switch"


    btndelete.classList.add("delete")
    btnswitch.classList.add("switch")

    btndelete.addEventListener("click",()=>{
        //TODO : call fetch delete + delete row
        deleteQuestion(_id)
    })
    btnswitch.addEventListener("click",()=>{
        //+ switch row
       question.etat=!question.etat
    })
    div.appendChild(span);
    div.appendChild(q);
    div.appendChild(btndelete);
    div.appendChild(btnswitch);

  
    const menu = document.querySelector('#menu');
    
    

      menu.appendChild(div)
}