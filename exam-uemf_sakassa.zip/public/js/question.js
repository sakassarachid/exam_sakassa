import { url } from "./config.js";
import { addquestiontodiv } from "./main.js";

export const load=()=>{
    fetch(url+"/questions",{
        method:"GET",
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res=>res.json()).then(data=>{
        //data => array
        data.forEach(element => {
            addquestiontodiv(element)
        });

    })
    .catch(err=>{
        alert("error");
        console.log(err)
    }).finally(()=>{
       
    })
}


export const addQuestion=(question,option)=>{
    const dataToSend = {
        question:question,
        etat:option,
    }
    fetch(url+"/questions",{
        method:"POST",
        body:JSON.stringify(dataToSend),
        headers:{
            'Content-Type': 'application/json'
        }
    }).then(res=>{
        if(res.ok)
        {
            res.json().then(data=>{
                addquestiontodiv(data)
            })
        }
        else{
            alert("erreur")
        }
    })
    .catch(err=>{
        alert("erreur")
        console.log(err)
    })
}
//mehdi.tmimi@usmba.ac.ma
export const deleteQuestion=(id)=>{
    fetch(url+"/questions/"+id,{
        method:"DELETE"
    }).then(res=>{
        if(res.ok)
        {
            document.getElementById(id).remove();
        }
        else
            alert("error")
    })
    .catch(err=>{
        alert("erreur")
        console.log(err)
    })
}
export const deleteall=()=>{
    fetch(url+"/questions/all",{
        method:"DELETE"
    }).then(res=>{
        res.json("success")
    })
    .catch(err=>{
        alert("erreur")
        console.log(err)
    })
}