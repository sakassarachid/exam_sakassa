const { json } = require('express');
const express= require('express')
const {Question} = require('../models/Question');
const router = express.Router();



//get
router.get("",async(req,res)=>{

    const questions= await Question.find();
    const nbr=req.query.nbr || questions.length
    if(nbr)
        res.json(questions.filter((elem,index)=>index<nbr));
    else
        res.json(await Question.find());      
})
//getbyid
router.get("/:id",async(req,res)=>{
  
    const {id}=req.params
    try{
        const result=await Question.findById(id)
        res.status(200).json({message : "find it!!",result})
    }catch(err){
        res.status(500).json({message:"err",err})
    } 
   

          
       
})


// ajouter
router.post("",async (req,res)=>{

    // recuperation des donnees envoyees
   const {question,etat} =  req.body
   // verification
   if( !question || !etat)
    return res.status(400).json({message:"id, question,etat are required"})

    // creer une instance du model
    const quest=new Question({
        question:question,
        etat:etat
    })
    
    try{
    
    const dataQuestion =  await quest.save()
    res.json(dataQuestion);

    }catch(err)
    {
        res.status(500).send({message:err})
    }


   
})




// modifier

router.put("/:idQuestion", async (req,res)=>{

    const  idQuestion = req.params.idQuestion
    const { question,etat } = req.body
    try {

        const result = await  Question.findByIdAndUpdate(idQuestion, { question, etat })
        res.status(200).json({ message: "Question updated", result })

    }
    catch (err) {
        res.status(500).json({ message: "error", err })
    }
})

router.delete("/all",async (req,res)=>{

 
    await Question.find().remove()

})
//supprimer ( method utilise en http : delete. l identifiant de la ressource doit etre dournie au niveau du URL)
// delete localhost:30000/questions/1245
router.delete("/:idQuestion",async (req,res)=>{

    const idQuestion=req.params.idQuestion
    Question.findByIdAndDelete(idQuestion).then(()=>{
        res.json({msg:'removed successfuly'})
       }).catch(err=>res.status(500).json({err:err.message}))
})




module.exports.questionsrouter= router;