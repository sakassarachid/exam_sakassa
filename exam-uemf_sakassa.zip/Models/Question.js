const {default:mongoose}=require('mongoose');


const schema = new mongoose.Schema({

    
    // id:{
    //     type:String,
    //     require:true
    // },
    question:{
        type:String,
        require:true
    },
    etat:{
        type:String,
        require:true
    }

})

const Question=mongoose.model("questions",schema)

module.exports={schemaQestion:schema,Question:Question}