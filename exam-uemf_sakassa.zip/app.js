const mongoose=require("mongoose")
const express=require("express")
const dotenv=require("dotenv")

const { questionsrouter } = require('./routes/questions')

dotenv.config();

//mongoose

mongoose.connect
(process.env.chaine_connection)
.then(()=>console.log("connected to mongodb atlas"))
.catch(err=>console.log(err))

//express

const app=express();
app.use(express.json())
app.use(express.static("./public"))
app.use('/questions',questionsrouter)

const port =process.env.port || 3000
app.listen(port, ()=>{
    console.log('server listening on port : ',port)
})